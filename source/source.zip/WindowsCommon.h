#ifndef ANDROID_COMMON_H
#define ANDROID_COMMON_H
#pragma once

#include "Common.h"

#endif